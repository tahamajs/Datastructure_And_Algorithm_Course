import sys

sys.setrecursionlimit(100000+10)

happinessList = []
neighsList = []

def find_max_happiness(index):
	sum_with_presence = happinessList[index]
	sum_without_presence = 0
	
	for neigh in neighsList[index]:
		sum_with_neigh, sum_without_neigh = find_max_happiness(neigh)
		sum_with_presence += sum_without_neigh
		sum_without_presence += max(sum_with_neigh, sum_without_neigh)

	return sum_with_presence, sum_without_presence

happinessList.append(0)
neighsList.append([])

n = int(input())
for i in range(n):
	x = input()
	h, m = list(map(int, x.split()))

	neighs = []
	if(m > 0):
		y = input()
		neighs = list(map(int, y.split()))

	happinessList.append(h)
	neighsList.append(neighs)

sum_with_owner, sum_without_owner = find_max_happiness(1)
print(sum_with_owner)

