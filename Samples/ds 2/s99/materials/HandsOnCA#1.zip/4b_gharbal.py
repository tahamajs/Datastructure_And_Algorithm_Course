
n = 100010
is_prime = [True] * n

is_prime[0] = False
is_prime[1] = False 

for i in range(n):
    if is_prime[i]:
        for j in range(i*i, n, i):
            is_prime[j] = False

q = int(input())
for i in range(q):
    x = int(input())
    print(is_prime[x])
