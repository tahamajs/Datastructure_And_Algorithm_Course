R_move = (0, 1)
L_move = (0, -1)
U_move = (1, 0)
D_move = (-1, 0)

def move(currLoc, direction):
	result = (currLoc[0] + direction[0], currLoc[1] + direction[1])
	return result

def count_passwords(pattern):
	result = 0
	for i in range(3):
		for j in range(3):
			visited[(i, j)] = True
			result += find_passwords((i, j), pattern)
			visited[(i, j)] = False
	return result

def get_move_unit(direction):
	if direction=="R":
		return R_move
	elif direction=="L":
		return L_move
	elif direction=="U":
		return U_move
	else:
		return D_move

def is_valid_move(new_loc, currLoc, i, move_unit):
	if not (new_loc[0]>-1 and new_loc[0]<3):
		return False
	if not (new_loc[1]>-1 and new_loc[1]<3):
		return False
	if i==2:
		middle_point = move(currLoc, move_unit)
		if visited[middle_point]:
			return False
	return not visited[new_loc]

def visit_locations(currLoc, newLoc, i, direction, state, left):
	move_unit = get_move_unit(direction)

	visited[newLoc] = True
	if i==2:
		visited[move(currLoc, move_unit)] = True

	prev = []
	if i==2 and (currLoc[0] + newLoc[0] == 2) and (currLoc[1] + newLoc[1] == 2) and left:
		if direction=='R' or direction=='L':
			row = 1
			if state==1:
				row = 0
			else:
				row = 2
			for index in range(3):
				prev.append(visited[(row, index)])
				visited[(row, index)] = True
		else: # direstion is U or D
			col = 1
			if state==1:
				col = 0
			else:
				col = 2
			for index in range(3):
				prev.append(visited[(index, col)])
				visited[(index, col)] = True
	return prev

def unvisit_locations(currLoc, newLoc, i, direction, state, left, prev):
	move_unit = get_move_unit(direction)

	visited[newLoc] = False
	if i==2:
		visited[move(currLoc, move_unit)] = False

	if i==2 and (currLoc[0] + newLoc[0] == 2) and (currLoc[1] + newLoc[1] == 2) and left:
		if direction=='R' or direction=='L':
			row = 1
			if state==1:
				row = 0
			else:
				row = 2
			for index in range(3):
				visited[(row, index)] = prev[index]
		else: # direstion is U or D
			col = 1
			if state==1:
				col = 0
			else:
				col = 2
			for index in range(3):
				visited[(index, col)] = prev[index]


def find_passwords(currLoc, pattern):
	if len(pattern)==0:
		# print("FINAL", visited)
		return 1

	direction = pattern[0]

	move_unit = get_move_unit(direction)
	
	result = 0	
	for i in [1, 2]:
		newLoc = currLoc
		for x in range(i):
			newLoc = move(newLoc, move_unit)
		if is_valid_move(newLoc, currLoc, i, move_unit):
			if i==2 and (currLoc[0] + newLoc[0] == 2) and (currLoc[1] + newLoc[1] == 2) and (len(pattern[1:])>0):
				for state in [1, 2]:
					prev = visit_locations(currLoc, newLoc, i, direction, state, True)
					result += find_passwords(newLoc, pattern[1:])
					unvisit_locations(currLoc, newLoc, i, direction, state, True, prev)
			else:
				visit_locations(currLoc, newLoc, i, direction, 1, False)
				result += find_passwords(newLoc, pattern[1:])
				unvisit_locations(currLoc, newLoc, i, direction, 1, False, [])
	return result

password_pattern = input()
visited = {}
for i in range(3):
	for j in range(3):
		visited[(i, j)] = False 
print(count_passwords(password_pattern)) 