
n, m = list(map(int, input().split()))

dx = [0, 1, 1, 1, 0, -1, -1, -1]
dy = [1, 1, 0, -1, -1, -1, 0, 1]

def is_inside(x, y):
    return 0 <= x < n and 0 <= y < m

a = []
for i in range(n):
    a.append(list(map(int, input().split())))

ans = []
for i in range(n):
    ans.append([0] * m)

for x in range(n):
    for y in range(m):
        for i in range(8):
            nx = x + dx[i]
            ny = y + dy[i]
            if is_inside(nx, ny):
                ans[x][y] += a[nx][ny]

for x in range(n):
    for y in range(m):
        print(ans[x][y], end=' ')
    print()
