mapping = {}

def match(text, i, pattern, j):
	n = len(text)
	m = len(pattern)

	if n < m:
		return False
	if i==n and j==m:
		return True
	if i==n or j==m:
		return False

	curr = pattern[j]

	if curr in mapping:
		s = mapping[curr]
		k = len(s)

		if not s==text[i:i+k]:
			return False


		return match(text, i+k, pattern, j+1)

	for k in range(1, n-i+1):
		mapping[curr] = text[i:i+k]

		if match(text, i+k, pattern, j+1):
			return True
		del mapping[curr]
	return False
	
n = int(input())
for i in range(n):
	mapping = {}
	text = input()
	pattern = input()
	if match(text, 0, pattern, 0):
		print("Yes")
	else:
		print("No")