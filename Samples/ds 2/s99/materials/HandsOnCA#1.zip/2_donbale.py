
a, l, r = list(map(int, input().split()))

if a == 0:
    if l <= 1 <= r:
        print("Inf")
    else:
        print(0)
elif a == 1:
    print(int((r*(r+1) - l*(l-1)) / 2))
else:
    ans = 0
    an = 1
    current = 1
    while current <= r:
        if l <= current <= r:
            ans += current
        current += an
        an *= a
    
    print(ans)
