def merge(arr1, arr2, sort_pattern, i):
	result = []
	arr1_i, arr2_i, index = 0, 0, i
	while (arr1_i<len(arr1)) and (arr2_i<len(arr2)):
		curr_action = sort_pattern[index]
		if curr_action=="L":
			result.append(arr1[arr1_i])
			arr1_i +=1;
		else:
			result.append(arr2[arr2_i])
			arr2_i +=1;
		index += 1;
	for elem in arr1[arr1_i:]:
		result.append(elem)

	for elem in arr2[arr2_i:]:
		result.append(elem)
	return result, index

def merge_sort(arr, sort_pattern, i):
	n = len(arr)
	if n <= 1:
		return arr, i
	mid = n//2
	first, index_f = merge_sort(arr[:mid], sort_pattern, i)
	second, index_s = merge_sort(arr[mid:], sort_pattern, index_f)
	return merge(first, second, sort_pattern, index_s)

def find_original_array(sorted_arr):
	dictionaty = {}
	l = len(sorted_arr)
	for i in range(l):
		dictionaty[sorted_arr[i]] = i+1
	original = []
	for i in range(l):
		original.append(dictionaty[i])
	return original

n = int(input())
sort_pattern = input()
numbers = list(range(n))

sorted_arr, x = merge_sort(numbers, sort_pattern, 0)
original = find_original_array(sorted_arr)
for i in range(len(original)):
	print(original[i], end=" ")
print()
