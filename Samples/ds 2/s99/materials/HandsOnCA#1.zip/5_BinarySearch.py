
n, m = list(map(int, input().split()))
a = list(map(int, input().split()))
b = list(map(int, input().split()))

for x in b:
    lo = 0
    hi = n
    while hi - lo > 1:
        md = (hi + lo) // 2
        if a[md] > x:
            hi = md
        else:
            lo = md
    if lo == 0 and a[0] > x:
        hi = 0
    print(hi)