import sys
#import and init pygame
import pygame
pygame.init() 

import random

#create the screen
window = pygame.display.set_mode((640, 480)) 

#draw a line - see http://www.pygame.org/docs/ref/draw.html for more 
pygame.draw.line(window, (255, 255, 255), (0, 0), (30, 50))

for _ in range(100):
	x_s = random.randint(0,640)
	x_e = random.randint(0,640)
	y_s = random.randint(0,480)
	y_e = random.randint(0,480)
	pygame.draw.line(window, (255, 255, 255), (x_s, y_s), (x_e, y_e))
	

#draw it to the screen
pygame.display.flip() 

#input handling (somewhat boilerplate code):
while True: 
	for event in pygame.event.get(): 
		if event.type == pygame.QUIT: 
			sys.exit(0) 
		else: 
			print event 

