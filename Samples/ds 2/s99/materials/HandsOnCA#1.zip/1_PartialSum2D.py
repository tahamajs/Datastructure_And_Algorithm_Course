
n, m, q = list(map(int, input().split()))

a = []
ps = []
for i in range(n+1):
    ps.append([0] * (m+1))

for i in range(n):
    a.append(list(map(int, input().split())))

for i in range(n):
    for j in range(m):
        ps[i+1][j+1] = ps[i+1][j] + ps[i][j+1] - ps[i][j] + a[i][j]

for i in range(q):
    xlo, ylo, xhi, yhi = list(map(int, input().split()))
    print(ps[xhi][yhi] - ps[xhi][ylo] - ps[xlo][yhi] + ps[xlo][ylo])
